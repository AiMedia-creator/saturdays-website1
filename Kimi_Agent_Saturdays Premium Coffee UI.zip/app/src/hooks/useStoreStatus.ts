import { useState, useEffect } from 'react';

interface StoreStatus {
  isOpen: boolean;
  statusText: string;
  nextChange: string;
}

export function useStoreStatus(): StoreStatus {
  const [status, setStatus] = useState<StoreStatus>({ isOpen: false, statusText: 'CLOSED', nextChange: '' });

  useEffect(() => {
    const checkStatus = () => {
      const now = new Date();
      const hours = now.getHours();
      const minutes = now.getMinutes();
      const currentTime = hours * 60 + minutes;

      const openTime = 8 * 60; // 8:00 AM
      const closeTime = 21 * 60; // 9:00 PM

      const isOpen = currentTime >= openTime && currentTime < closeTime;

      let nextChange = '';
      if (isOpen) {
        const minsUntilClose = closeTime - currentTime;
        const closeHours = Math.floor(minsUntilClose / 60);
        const closeMins = minsUntilClose % 60;
        nextChange = `Closes in ${closeHours}h ${closeMins}m`;
      } else {
        if (currentTime < openTime) {
          const minsUntilOpen = openTime - currentTime;
          const openHours = Math.floor(minsUntilOpen / 60);
          const openMins = minsUntilOpen % 60;
          nextChange = `Opens in ${openHours}h ${openMins}m`;
        } else {
          nextChange = 'Opens tomorrow at 8:00 AM';
        }
      }

      setStatus({
        isOpen,
        statusText: isOpen ? 'OPEN NOW' : 'CLOSED',
        nextChange,
      });
    };

    checkStatus();
    const interval = setInterval(checkStatus, 60000);
    return () => clearInterval(interval);
  }, []);

  return status;
}
