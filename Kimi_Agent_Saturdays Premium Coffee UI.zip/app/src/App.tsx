import { useEffect } from 'react';
import { CartProvider } from '@/context/CartContext';
import AnnouncementBar from '@/sections/AnnouncementBar';
import Navbar from '@/sections/Navbar';
import Hero from '@/sections/Hero';
import Signatures from '@/sections/Signatures';
import Menu from '@/sections/Menu';
import CartDrawer from '@/sections/CartDrawer';
import Reviews from '@/sections/Reviews';
import Location from '@/sections/Location';
import Footer from '@/sections/Footer';

function App() {
  useEffect(() => {
    document.title = 'Saturdays - Specialty Matcha & Coffee | Nasr City, Cairo';

    let metaDescription = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.name = 'description';
      document.head.appendChild(metaDescription);
    }
    metaDescription.content =
      'Saturdays is a specialty matcha and coffee house in Nasr City, Cairo. Premium Japanese Uji Matcha, artisanal coffee blends, and handcrafted beverages. Order online for pickup!';
  }, []);

  return (
    <CartProvider>
      <div className="min-h-screen bg-sbg">
        <AnnouncementBar />
        <Navbar />
        <CartDrawer />
        <main>
          <Hero />
          <Signatures />
          <Menu />
          <Reviews />
          <Location />
        </main>
        <Footer />
      </div>
    </CartProvider>
  );
}

export default App;
