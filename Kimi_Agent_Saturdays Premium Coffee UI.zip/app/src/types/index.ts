export type Category = 'all' | 'matcha' | 'coffee' | 'blended' | 'hot-drinks';

export type Sweetness = 'none' | 'less' | 'normal' | 'extra';

export type MilkOption = 'whole' | 'oat' | 'coconut' | 'none';

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'matcha' | 'coffee' | 'blended' | 'hot-drinks';
  imageGradient: string;
  tag?: string;
  isPopular?: boolean;
}

export interface CartItemCustomization {
  sweetness: Sweetness;
  milk: MilkOption;
}

export interface CartItem {
  cartId: string;
  item: MenuItem;
  quantity: number;
  customization: CartItemCustomization;
  finalPrice: number;
}

export interface Review {
  id: string;
  name: string;
  reviewCount: string;
  photoCount?: string;
  rating: number;
  date: string;
  text: string;
  food?: number;
  service?: number;
  atmosphere?: number;
}

export interface MixerState {
  baseLayer: 'classic' | 'strawberry' | 'blueberry' | 'passion';
  matchaFloat: boolean;
  iceCubes: number;
  sweetness: Sweetness;
}

export const SWEETNESS_LABELS: Record<Sweetness, string> = {
  none: 'No Sweetness',
  less: 'Less Sweetness',
  normal: 'Normal Sweetness',
  extra: 'Extra Sweet',
};

export const MILK_LABELS: Record<MilkOption, string> = {
  whole: 'Whole Milk',
  oat: 'Oat Milk (+20 EGP)',
  coconut: 'Coconut Milk (+20 EGP)',
  none: 'No Milk',
};

export const MILK_PRICES: Record<MilkOption, number> = {
  whole: 0,
  oat: 20,
  coconut: 20,
  none: 0,
};

export const CATEGORY_LABELS: Record<Category, string> = {
  all: 'All Drinks',
  matcha: 'Specialty Matcha',
  coffee: 'Iced Coffee',
  blended: 'Blended Iced',
  'hot-drinks': 'Hot Drinks',
};

export const BASE_LAYER_COLORS: Record<string, string> = {
  classic: 'linear-gradient(to top, #f5f0e8 0%, #faf8f5 100%)',
  strawberry: 'linear-gradient(to top, #f8d0d8 0%, #fce8ec 100%)',
  blueberry: 'linear-gradient(to top, #c8d0e8 0%, #e0e4f0 100%)',
  passion: 'linear-gradient(to top, #f8e0a0 0%, #fcf0d0 100%)',
};
