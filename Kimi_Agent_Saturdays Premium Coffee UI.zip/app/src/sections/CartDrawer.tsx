import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Minus, Plus, ShoppingBag, MapPin, Phone, User, Send, Truck, Store } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { SWEETNESS_LABELS, MILK_LABELS } from '@/types';

type OrderType = 'pickup' | 'delivery';

export default function CartDrawer() {
  const {
    items,
    isCartOpen,
    closeCart,
    removeItem,
    updateQuantity,
    totalPrice,
    clearCart,
  } = useCart();

  const [showCheckout, setShowCheckout] = useState(false);
  const [orderType, setOrderType] = useState<OrderType>('pickup');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [orderSent, setOrderSent] = useState(false);

  const handleSubmit = () => {
    if (!name.trim() || !phone.trim()) return;
    if (orderType === 'delivery' && !address.trim()) return;

    const orderLines = items.map((item, i) => {
      const customParts = [];
      customParts.push(`Sweetness: ${SWEETNESS_LABELS[item.customization.sweetness]}`);
      customParts.push(`Milk: ${MILK_LABELS[item.customization.milk]}`);
      return `${i + 1}. ${item.item.name}\n   ${customParts.join(' | ')}\n   ${item.finalPrice} EGP x ${item.quantity} = ${item.finalPrice * item.quantity} EGP`;
    });

    const message = `
*New Order from Saturdays!*

*Customer:* ${name}
*Phone:* ${phone}
*Order Type:* ${orderType === 'pickup' ? 'Store Pickup' : 'Delivery'}
${orderType === 'delivery' ? `*Address:* ${address}` : ''}

*Order Details:*
${orderLines.join('\n\n')}

*Grand Total: ${totalPrice} EGP*
    `.trim();

    const encoded = encodeURIComponent(message);
    window.open(`https://wa.me/201557897297?text=${encoded}`, '_blank');
    setOrderSent(true);
  };

  const handleClose = () => {
    closeCart();
    setTimeout(() => {
      setShowCheckout(false);
      setOrderSent(false);
      setName('');
      setPhone('');
      setAddress('');
    }, 300);
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <div className="fixed inset-0 z-50">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="absolute inset-0 bg-sprimary/30 backdrop-blur-sm"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-sbg shadow-2xl flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-ssand">
              <div className="flex items-center gap-3">
                <ShoppingBag className="w-5 h-5 text-sprimary" />
                <h2 className="font-outfit font-bold text-xl text-sprimary">Your Cart</h2>
                {items.length > 0 && (
                  <span className="bg-ssecondary text-white text-xs font-outfit font-bold px-2 py-0.5 rounded-full">
                    {items.length}
                  </span>
                )}
              </div>
              <button
                onClick={handleClose}
                className="w-8 h-8 rounded-full bg-ssand/50 flex items-center justify-center hover:bg-ssand transition-colors"
              >
                <X className="w-4 h-4 text-sprimary" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto scrollbar-hide">
              {items.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center p-8">
                  <ShoppingBag className="w-16 h-16 text-ssand mb-4" />
                  <p className="font-outfit font-semibold text-lg text-sprimary mb-2">
                    Your cart is empty
                  </p>
                  <p className="font-jakarta text-sm text-smuted mb-6">
                    Add some drinks to get started
                  </p>
                  <button onClick={handleClose} className="btn-primary">
                    Browse Menu
                  </button>
                </div>
              ) : !showCheckout ? (
                /* Cart Items */
                <div className="p-5 space-y-4">
                  {items.map(cartItem => (
                    <motion.div
                      key={cartItem.cartId}
                      layout
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="bg-white rounded-2xl p-4 border border-ssand"
                    >
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-outfit font-semibold text-sm text-sprimary truncate">
                            {cartItem.item.name}
                          </h4>
                          <p className="font-jakarta text-[11px] text-smuted mt-0.5">
                            {SWEETNESS_LABELS[cartItem.customization.sweetness]} ·{' '}
                            {MILK_LABELS[cartItem.customization.milk]}
                          </p>
                        </div>
                        <button
                          onClick={() => removeItem(cartItem.cartId)}
                          className="text-smuted hover:text-ssecondary transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateQuantity(cartItem.cartId, -1)}
                            className="w-7 h-7 rounded-lg bg-ssand/50 flex items-center justify-center hover:bg-ssand transition-colors"
                          >
                            <Minus className="w-3 h-3 text-sprimary" />
                          </button>
                          <span className="font-outfit font-semibold text-sm text-sprimary w-5 text-center">
                            {cartItem.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(cartItem.cartId, 1)}
                            className="w-7 h-7 rounded-lg bg-ssand/50 flex items-center justify-center hover:bg-ssand transition-colors"
                          >
                            <Plus className="w-3 h-3 text-sprimary" />
                          </button>
                        </div>
                        <span className="font-outfit font-bold text-sprimary">
                          {cartItem.finalPrice * cartItem.quantity} EGP
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : !orderSent ? (
                /* Checkout Form */
                <div className="p-5 space-y-5">
                  <h3 className="font-outfit font-bold text-lg text-sprimary">Checkout Details</h3>

                  {/* Order Type Toggle */}
                  <div className="grid grid-cols-2 gap-2 p-1 bg-ssand/50 rounded-xl">
                    <button
                      onClick={() => setOrderType('pickup')}
                      className={`flex items-center justify-center gap-2 py-2.5 rounded-lg font-jakarta text-sm font-medium transition-all ${
                        orderType === 'pickup'
                          ? 'bg-white text-sprimary shadow-sm'
                          : 'text-smuted hover:text-sprimary'
                      }`}
                    >
                      <Store className="w-4 h-4" />
                      Pickup
                    </button>
                    <button
                      onClick={() => setOrderType('delivery')}
                      className={`flex items-center justify-center gap-2 py-2.5 rounded-lg font-jakarta text-sm font-medium transition-all ${
                        orderType === 'delivery'
                          ? 'bg-white text-sprimary shadow-sm'
                          : 'text-smuted hover:text-sprimary'
                      }`}
                    >
                      <Truck className="w-4 h-4" />
                      Delivery
                    </button>
                  </div>

                  {/* Name */}
                  <div>
                    <label className="font-jakarta text-sm text-smuted mb-1.5 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5" />
                      Full Name *
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder="Enter your name"
                      className="w-full px-4 py-3 rounded-xl bg-white border border-ssand font-jakarta text-sm text-sprimary placeholder:text-smuted/50 focus:outline-none focus:ring-2 focus:ring-sprimary/20 focus:border-sprimary/30"
                    />
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="font-jakarta text-sm text-smuted mb-1.5 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5" />
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      placeholder="01xxxxxxxxxx"
                      className="w-full px-4 py-3 rounded-xl bg-white border border-ssand font-jakarta text-sm text-sprimary placeholder:text-smuted/50 focus:outline-none focus:ring-2 focus:ring-sprimary/20 focus:border-sprimary/30"
                    />
                  </div>

                  {/* Address (if delivery) */}
                  <AnimatePresence>
                    {orderType === 'delivery' && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                      >
                        <label className="font-jakarta text-sm text-smuted mb-1.5 flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5" />
                          Delivery Address *
                        </label>
                        <textarea
                          value={address}
                          onChange={e => setAddress(e.target.value)}
                          placeholder="Enter your full address"
                          rows={3}
                          className="w-full px-4 py-3 rounded-xl bg-white border border-ssand font-jakarta text-sm text-sprimary placeholder:text-smuted/50 focus:outline-none focus:ring-2 focus:ring-sprimary/20 focus:border-sprimary/30 resize-none"
                        />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                /* Order Sent Confirmation */
                <div className="flex flex-col items-center justify-center h-full text-center p-8">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', damping: 15 }}
                    className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4"
                  >
                    <Send className="w-8 h-8 text-green-600" />
                  </motion.div>
                  <h3 className="font-outfit font-bold text-xl text-sprimary mb-2">
                    Order Sent!
                  </h3>
                  <p className="font-jakarta text-sm text-smuted mb-6">
                    Redirecting you to WhatsApp to complete your order...
                  </p>
                  <button
                    onClick={() => {
                      clearCart();
                      handleClose();
                    }}
                    className="btn-primary"
                  >
                    Done
                  </button>
                </div>
              )}
            </div>

            {/* Footer */}
            {items.length > 0 && !orderSent && (
              <div className="p-5 border-t border-ssand bg-white/50">
                {!showCheckout ? (
                  <>
                    <div className="flex items-center justify-between mb-4">
                      <span className="font-jakarta text-sm text-smuted">Subtotal</span>
                      <span className="font-outfit font-bold text-xl text-sprimary">
                        {totalPrice} EGP
                      </span>
                    </div>
                    <button
                      onClick={() => setShowCheckout(true)}
                      className="w-full btn-secondary py-3.5 flex items-center justify-center gap-2"
                    >
                      Proceed to Checkout
                      <Send className="w-4 h-4" />
                    </button>
                  </>
                ) : (
                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowCheckout(false)}
                      className="flex-1 py-3.5 rounded-xl border-2 border-ssand text-sprimary font-outfit font-medium hover:bg-ssand/50 transition-colors"
                    >
                      Back
                    </button>
                    <button
                      onClick={handleSubmit}
                      disabled={!name.trim() || !phone.trim() || (orderType === 'delivery' && !address.trim())}
                      className="flex-[2] btn-primary py-3.5 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Send className="w-4 h-4" />
                      Order via WhatsApp
                    </button>
                  </div>
                )}
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
