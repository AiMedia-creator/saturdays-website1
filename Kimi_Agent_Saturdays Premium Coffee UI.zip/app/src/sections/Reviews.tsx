import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';
import { reviews } from '@/data/reviews';

export default function Reviews() {
  const displayReviews = reviews.slice(0, 8);

  return (
    <section id="reviews" className="py-20 section-padding">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 bg-saccent/60 text-sprimary text-xs font-jakarta font-medium rounded-full mb-4">
            Testimonials
          </span>
          <h2 className="font-outfit text-4xl sm:text-5xl font-bold text-sprimary mb-4">
            What Our Guests Say
          </h2>
          <div className="flex items-center justify-center gap-2 mb-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className="w-6 h-6 fill-amber-400 text-amber-400" />
            ))}
          </div>
          <p className="font-jakarta text-smuted">
            Rated 5.0 on Google Maps with 17+ reviews
          </p>
        </motion.div>

        {/* Reviews Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {displayReviews.map((review, index) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
              className="bg-white rounded-2xl p-5 border border-ssand hover:shadow-subtle transition-all duration-300"
            >
              {/* Quote icon */}
              <Quote className="w-6 h-6 text-saccent mb-3" />

              {/* Stars */}
              <div className="flex items-center gap-0.5 mb-3">
                {Array.from({ length: review.rating }).map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                ))}
              </div>

              {/* Review Text */}
              <p className="font-jakarta text-sm text-sprimary leading-relaxed mb-4">
                {review.text}
              </p>

              {/* Rating Breakdown */}
              {(review.food || review.service || review.atmosphere) && (
                <div className="flex flex-wrap gap-2 mb-3">
                  {review.food && (
                    <span className="text-[10px] font-jakarta bg-green-50 text-green-700 px-2 py-0.5 rounded-full">
                      Food: {review.food}
                    </span>
                  )}
                  {review.service && (
                    <span className="text-[10px] font-jakarta bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full">
                      Service: {review.service}
                    </span>
                  )}
                  {review.atmosphere && (
                    <span className="text-[10px] font-jakarta bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full">
                      Atmosphere: {review.atmosphere}
                    </span>
                  )}
                </div>
              )}

              {/* Reviewer Info */}
              <div className="flex items-center gap-3 pt-3 border-t border-ssand">
                <div className="w-9 h-9 rounded-full bg-sprimary flex items-center justify-center shrink-0">
                  <span className="text-white font-outfit font-semibold text-sm">
                    {review.name.charAt(0)}
                  </span>
                </div>
                <div className="min-w-0">
                  <p className="font-outfit font-semibold text-sm text-sprimary truncate">
                    {review.name}
                  </p>
                  <p className="font-jakarta text-[11px] text-smuted">
                    {review.reviewCount} · {review.date}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
