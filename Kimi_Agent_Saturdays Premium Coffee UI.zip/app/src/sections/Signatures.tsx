import { motion } from 'framer-motion';
import { Star } from 'lucide-react';
import { signatureDrinks } from '@/data/reviews';

function RatingBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs font-jakarta text-smuted w-20 shrink-0">{label}</span>
      <div className="flex-1 h-2 bg-ssand rounded-full overflow-hidden">
        <motion.div
          className="h-full rounded-full"
          style={{ backgroundColor: color }}
          initial={{ width: 0 }}
          whileInView={{ width: `${(value / 5) * 100}%` }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        />
      </div>
      <span className="text-xs font-outfit font-semibold text-sprimary w-6 text-right">{value}/5</span>
    </div>
  );
}

export default function Signatures() {
  return (
    <section id="signatures" className="py-20 section-padding">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 bg-saccent/60 text-sprimary text-xs font-jakarta font-medium rounded-full mb-4">
            Best Sellers
          </span>
          <h2 className="font-outfit text-4xl sm:text-5xl font-bold text-sprimary mb-4">
            Saturdays Signatures
          </h2>
            <p className="font-jakarta text-smuted max-w-xl mx-auto">
            Our most loved creations, handcrafted with premium Japanese Uji Matcha
          </p>
        </motion.div>

        {/* Signature Cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {signatureDrinks.map((drink, index) => (
            <motion.div
              key={drink.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="group"
            >
              <div className="glass-card rounded-3xl overflow-hidden transition-all duration-300 hover:shadow-elevated hover:-translate-y-1">
                {/* Drink Visual */}
                <div
                  className={`${drink.gradient} h-56 relative flex items-center justify-center overflow-hidden`}
                >
                  {/* Decorative circles */}
                  <div className="absolute top-4 left-4 w-20 h-20 bg-white/20 rounded-full blur-xl" />
                  <div className="absolute bottom-4 right-4 w-16 h-16 bg-white/15 rounded-full blur-lg" />

                  {/* Cup representation */}
                  <div className="relative z-10">
                    <div
                      className="w-28 h-36 rounded-b-2xl border-2 border-white/50 bg-white/10 backdrop-blur-sm relative overflow-hidden shadow-lg"
                    >
                      <div
                        className="absolute bottom-0 left-0 right-0 h-3/4"
                        style={{
                          background: `linear-gradient(to top, ${drink.colors.bottom} 0%, ${drink.colors.top} 100%)`,
                        }}
                      />
                      <div className="absolute inset-0 bg-white/5" />
                      {/* Ice cubes */}
                      <div className="absolute bottom-8 left-4 w-5 h-5 bg-white/25 rounded border border-white/30" />
                      <div className="absolute bottom-12 right-5 w-4 h-4 bg-white/20 rounded border border-white/30" />
                    </div>
                    <div className="mx-auto w-20 h-3 bg-sprimary/10 rounded-full blur-sm mt-1" />
                  </div>

                  {/* Price Tag */}
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full shadow-subtle">
                    <span className="font-outfit font-bold text-sprimary">{drink.price} EGP</span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="font-outfit font-semibold text-xl text-sprimary mb-2">
                    {drink.name}
                  </h3>
                  <p className="font-jakarta text-sm text-smuted leading-relaxed mb-4">
                    {drink.description}
                  </p>

                  {/* Rating Bars */}
                  <div className="space-y-2">
                    <RatingBar label="Earthy Notes" value={drink.rating.earthy} color="#7ba86a" />
                    <RatingBar label="Fruity Sweet" value={drink.rating.fruity} color="#BF6A5A" />
                    <RatingBar label="Creaminess" value={drink.rating.creamy} color="#d4a855" />
                  </div>

                  {/* Stars */}
                  <div className="flex items-center gap-1 mt-4 pt-4 border-t border-ssand">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                    <span className="text-xs font-jakarta text-smuted ml-2">5.0 (17 reviews)</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
