import { Coffee, Leaf } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-sprimary text-white py-16 section-padding">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                <span className="font-outfit font-bold text-xl text-white">S</span>
              </div>
              <div>
                <h3 className="font-outfit font-bold text-lg">Saturdays</h3>
                <p className="font-jakarta text-xs text-white/50 -mt-0.5">Matcha & Coffee</p>
              </div>
            </div>
            <p className="font-jakarta text-sm text-white/60 leading-relaxed max-w-xs">
              A specialty matcha and coffee oasis in Nasr City, Cairo. Premium Japanese Uji Matcha
              blended with love.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-outfit font-semibold text-sm mb-4 text-white/80">Quick Links</h4>
            <div className="space-y-2.5">
              {[
                { label: 'Menu', target: '#menu' },
                { label: 'Signatures', target: '#signatures' },
                { label: 'Reviews', target: '#reviews' },
                { label: 'Location', target: '#location' },
              ].map(link => (
                <button
                  key={link.target}
                  onClick={() => {
                    const el = document.querySelector(link.target);
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="block font-jakarta text-sm text-white/50 hover:text-white transition-colors"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-outfit font-semibold text-sm mb-4 text-white/80">Contact</h4>
            <div className="space-y-2.5 font-jakarta text-sm text-white/50">
              <p>15 Al Mahrouki, Al Golf</p>
              <p>Nasr City, Cairo</p>
              <p>Daily: 8:00 AM — 9:00 PM</p>
              <p>0155 789 7297</p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-jakarta text-xs text-white/40">
            &copy; {new Date().getFullYear()} Saturdays. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-1.5 text-white/40">
              <Coffee className="w-3.5 h-3.5" />
              <span className="font-jakarta text-xs">Premium Coffee</span>
            </div>
            <div className="flex items-center gap-1.5 text-white/40">
              <Leaf className="w-3.5 h-3.5" />
              <span className="font-jakarta text-xs">Japanese Matcha</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
