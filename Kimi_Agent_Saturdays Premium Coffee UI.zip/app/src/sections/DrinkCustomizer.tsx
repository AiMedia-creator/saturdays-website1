import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Minus } from 'lucide-react';
import type { MenuItem, Sweetness, MilkOption, CartItemCustomization } from '@/types';
import { SWEETNESS_LABELS, MILK_LABELS, MILK_PRICES } from '@/types';
import { useCart } from '@/context/CartContext';

interface DrinkCustomizerProps {
  item: MenuItem | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function DrinkCustomizer({ item, isOpen, onClose }: DrinkCustomizerProps) {
  const { addItem } = useCart();
  const [sweetness, setSweetness] = useState<Sweetness>('normal');
  const [milk, setMilk] = useState<MilkOption>('whole');
  const [quantity, setQuantity] = useState(1);

  const finalPrice = useMemo(() => {
    if (!item) return 0;
    return (item.price + MILK_PRICES[milk]) * quantity;
  }, [item, milk, quantity]);

  const handleAdd = () => {
    if (!item) return;
    const customization: CartItemCustomization = { sweetness, milk };
    for (let i = 0; i < quantity; i++) {
      addItem(item, customization);
    }
    onClose();
    setQuantity(1);
    setSweetness('normal');
    setMilk('whole');
  };

  return (
    <AnimatePresence>
      {isOpen && item && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-sprimary/40 backdrop-blur-sm" />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            onClick={(e: React.MouseEvent) => e.stopPropagation()}
            className="relative w-full max-w-lg bg-sbg rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto scrollbar-hide"
          >
            {/* Header with gradient */}
            <div className={`${item.imageGradient} p-6 relative`}>
              <button
                onClick={onClose}
                className="absolute top-4 right-4 w-8 h-8 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors"
              >
                <X className="w-4 h-4 text-sprimary" />
              </button>

              <div className="flex items-center gap-4">
                <div className="w-16 h-20 rounded-b-xl border-2 border-white/50 bg-white/15 backdrop-blur-sm relative overflow-hidden shrink-0">
                  <div
                    className="absolute bottom-0 left-0 right-0 h-3/4"
                    style={{
                      background:
                        item.category === 'matcha'
                          ? 'linear-gradient(to top, #7ba86a, #E5ECC8)'
                          : item.category === 'coffee'
                          ? 'linear-gradient(to top, #a89078, #d4c8b8)'
                          : item.category === 'blended'
                          ? 'linear-gradient(to top, #c8b8a0, #e8ddd0)'
                          : 'linear-gradient(to top, #8a7a68, #c4b8a8)',
                    }}
                  />
                </div>
                <div>
                  <h3 className="font-outfit font-bold text-xl text-sprimary">{item.name}</h3>
                  <p className="font-jakarta text-sm text-smuted mt-0.5 line-clamp-2">
                    {item.description}
                  </p>
                  <p className="font-outfit font-bold text-ssecondary mt-1">{item.price} EGP</p>
                </div>
              </div>
            </div>

            {/* Customization Options */}
            <div className="p-6 space-y-6">
              {/* Sweetness */}
              <div>
                <h4 className="font-outfit font-semibold text-sm text-sprimary mb-3">
                  Sweetness Level
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  {(['none', 'less', 'normal', 'extra'] as Sweetness[]).map(s => (
                    <button
                      key={s}
                      onClick={() => setSweetness(s)}
                      className={`py-2.5 px-3 rounded-xl font-jakarta text-sm transition-all duration-200 ${
                        sweetness === s
                          ? 'bg-sprimary text-white shadow-subtle'
                          : 'bg-ssand/50 text-smuted hover:bg-ssand'
                      }`}
                    >
                      {SWEETNESS_LABELS[s]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Milk Options */}
              <div>
                <h4 className="font-outfit font-semibold text-sm text-sprimary mb-3">
                  Milk Options
                </h4>
                <div className="space-y-2">
                  {(['whole', 'oat', 'coconut', 'none'] as MilkOption[]).map(m => (
                    <button
                      key={m}
                      onClick={() => setMilk(m)}
                      className={`w-full flex items-center justify-between py-3 px-4 rounded-xl font-jakarta text-sm transition-all duration-200 ${
                        milk === m
                          ? 'bg-sprimary text-white shadow-subtle'
                          : 'bg-ssand/50 text-smuted hover:bg-ssand'
                      }`}
                    >
                      <span>{MILK_LABELS[m]}</span>
                      {MILK_PRICES[m] > 0 && (
                        <span className={milk === m ? 'text-white/80' : 'text-smuted'}>
                          +{MILK_PRICES[m]} EGP
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity */}
              <div>
                <h4 className="font-outfit font-semibold text-sm text-sprimary mb-3">Quantity</h4>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setQuantity(q => Math.max(1, q - 1))}
                    className="w-10 h-10 rounded-xl bg-ssand/50 flex items-center justify-center hover:bg-ssand transition-colors"
                  >
                    <Minus className="w-4 h-4 text-sprimary" />
                  </button>
                  <span className="font-outfit font-bold text-xl text-sprimary w-8 text-center">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(q => Math.min(10, q + 1))}
                    className="w-10 h-10 rounded-xl bg-ssand/50 flex items-center justify-center hover:bg-ssand transition-colors"
                  >
                    <Plus className="w-4 h-4 text-sprimary" />
                  </button>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-6 border-t border-ssand bg-white/50">
              <div className="flex items-center justify-between mb-4">
                <span className="font-jakarta text-sm text-smuted">Total</span>
                <span className="font-outfit font-bold text-2xl text-sprimary">{finalPrice} EGP</span>
              </div>
              <button
                onClick={handleAdd}
                className="w-full btn-primary py-3.5 flex items-center justify-center gap-2 text-base"
              >
                <Plus className="w-5 h-5" />
                Add to Cart
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
