import { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronRight, Minus, Plus } from 'lucide-react';
import type { MixerState } from '@/types';
import { BASE_LAYER_COLORS, SWEETNESS_LABELS } from '@/types';

const BASE_OPTIONS = [
  { id: 'classic' as const, label: 'Classic Milk', color: '#f5f0e8' },
  { id: 'strawberry' as const, label: 'Strawberry', color: '#f8d0d8' },
  { id: 'blueberry' as const, label: 'Blueberry', color: '#c8d0e8' },
  { id: 'passion' as const, label: 'Passion Fruit', color: '#f8e0a0' },
];

const SWEETNESS_OPTIONS: Array<{ id: MixerState['sweetness']; label: string }> = [
  { id: 'none', label: 'None' },
  { id: 'less', label: 'Less' },
  { id: 'normal', label: 'Normal' },
  { id: 'extra', label: 'Extra' },
];

export default function Hero() {
  const [mixer, setMixer] = useState<MixerState>({
    baseLayer: 'classic',
    matchaFloat: false,
    iceCubes: 2,
    sweetness: 'normal',
  });

  const updateMixer = (updates: Partial<MixerState>) => {
    setMixer(prev => ({ ...prev, ...updates }));
  };

  const scrollToMenu = () => {
    const el = document.querySelector('#menu');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="min-h-screen pt-28 pb-16 section-padding flex items-center">
      <div className="max-w-7xl mx-auto w-full">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Column - Text */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            <span className="inline-block px-4 py-1.5 bg-saccent/60 text-sprimary text-xs font-jakarta font-medium rounded-full mb-6">
              Specialty Matcha & Coffee
            </span>
            <h1 className="font-outfit text-5xl sm:text-6xl lg:text-7xl font-bold text-sprimary leading-[1.05] mb-6">
              Slow down.
              <br />
              <span className="text-smuted">Sip slowly.</span>
            </h1>
            <p className="font-jakarta text-smuted text-base sm:text-lg leading-relaxed max-w-lg mb-8">
              Saturdays is a specialty Matcha and Coffee oasis in Nasr City, Cairo. We blend premium
              Japanese Uji Matcha with creamy milks and fresh fruit infusions.
            </p>
            <div className="flex flex-wrap gap-4">
              <button onClick={scrollToMenu} className="btn-primary flex items-center gap-2">
                Explore Menu
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  const el = document.querySelector('#signatures');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-6 py-3 border-2 border-sprimary/20 text-sprimary font-outfit font-medium rounded-lg hover:border-sprimary/40 transition-colors duration-200"
              >
                View Signatures
              </button>
            </div>
          </motion.div>

          {/* Right Column - Matcha Mixer Widget */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2, ease: 'easeOut' }}
            className="flex flex-col items-center"
          >
            {/* Glass Cup */}
            <div className="relative w-56 sm:w-64 mb-8">
              {/* Cup Body */}
              <div className="relative mx-auto w-48 sm:w-56 h-72 sm:h-80 rounded-b-3xl border-2 border-white/60 bg-white/10 backdrop-blur-sm overflow-hidden shadow-glass">
                {/* Liquid Layers */}
                <div className="absolute inset-0 flex flex-col justify-end">
                  {/* Base Layer */}
                  <motion.div
                    className="w-full rounded-b-3xl"
                    initial={false}
                    animate={{
                      height: mixer.matchaFloat ? '50%' : '75%',
                      background: BASE_LAYER_COLORS[mixer.baseLayer],
                    }}
                    transition={{ duration: 0.6, ease: 'easeInOut' }}
                  />

                  {/* Matcha Float Layer */}
                  <motion.div
                    className="absolute top-0 left-0 right-0"
                    initial={false}
                    animate={{
                      height: mixer.matchaFloat ? '45%' : '0%',
                      opacity: mixer.matchaFloat ? 1 : 0,
                    }}
                    transition={{ duration: 0.6, ease: 'easeInOut' }}
                    style={{
                      background: 'linear-gradient(to bottom, #7ba86a 0%, #9bc48a 60%, rgba(155, 196, 138, 0.3) 100%)',
                    }}
                  />

                  {/* Ice Cubes */}
                  {Array.from({ length: mixer.iceCubes }).map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-6 h-6 bg-white/30 rounded-md border border-white/40 backdrop-blur-md"
                      initial={false}
                      animate={{
                        bottom: `${35 + i * 18}%`,
                        left: `${20 + (i % 3) * 25}%`,
                        rotate: i * 15,
                      }}
                      transition={{ duration: 0.5, ease: 'easeOut' }}
                    />
                  ))}
                </div>

                {/* Glass Reflection */}
                <div className="absolute inset-0 rounded-b-3xl pointer-events-none">
                  <div className="absolute top-0 left-4 w-3 h-full bg-white/10 rounded-full" />
                  <div className="absolute top-0 right-6 w-1.5 h-2/3 bg-white/5 rounded-full" />
                </div>
              </div>

              {/* Cup Shadow */}
              <div className="mx-auto w-40 h-4 bg-sprimary/10 rounded-full blur-md mt-2" />
            </div>

            {/* Mixer Controls */}
            <div className="w-full max-w-sm glass-card rounded-2xl p-5 space-y-5">
              {/* Base Layer Selector */}
              <div>
                <label className="font-outfit font-medium text-sm text-sprimary mb-2 block">
                  Base Layer
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {BASE_OPTIONS.map(opt => (
                    <button
                      key={opt.id}
                      onClick={() => updateMixer({ baseLayer: opt.id })}
                      className={`flex flex-col items-center gap-1.5 p-2 rounded-xl transition-all duration-200 ${
                        mixer.baseLayer === opt.id
                          ? 'bg-sprimary text-white shadow-subtle'
                          : 'bg-ssand/50 text-smuted hover:bg-ssand'
                      }`}
                    >
                      <span
                        className="w-5 h-5 rounded-full border-2 border-white/40 shadow-sm"
                        style={{ backgroundColor: opt.color }}
                      />
                      <span className="text-[10px] font-jakarta font-medium">{opt.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Matcha Float Toggle */}
              <div className="flex items-center justify-between">
                <span className="font-outfit font-medium text-sm text-sprimary">Matcha Float</span>
                <button
                  onClick={() => updateMixer({ matchaFloat: !mixer.matchaFloat })}
                  className={`relative w-12 h-7 rounded-full transition-colors duration-300 ${
                    mixer.matchaFloat ? 'bg-sprimary' : 'bg-ssand'
                  }`}
                >
                  <motion.div
                    className="absolute top-1 w-5 h-5 bg-white rounded-full shadow-sm"
                    animate={{ left: mixer.matchaFloat ? 'calc(100% - 24px)' : '4px' }}
                    transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                  />
                </button>
              </div>

              {/* Ice Cubes */}
              <div className="flex items-center justify-between">
                <span className="font-outfit font-medium text-sm text-sprimary">Ice Cubes</span>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => updateMixer({ iceCubes: Math.max(0, mixer.iceCubes - 1) })}
                    className="w-8 h-8 rounded-lg bg-ssand/50 flex items-center justify-center hover:bg-ssand transition-colors"
                  >
                    <Minus className="w-4 h-4 text-sprimary" />
                  </button>
                  <span className="font-outfit font-semibold text-sprimary w-4 text-center">
                    {mixer.iceCubes}
                  </span>
                  <button
                    onClick={() => updateMixer({ iceCubes: Math.min(6, mixer.iceCubes + 1) })}
                    className="w-8 h-8 rounded-lg bg-ssand/50 flex items-center justify-center hover:bg-ssand transition-colors"
                  >
                    <Plus className="w-4 h-4 text-sprimary" />
                  </button>
                </div>
              </div>

              {/* Sweetness Selector */}
              <div>
                <label className="font-outfit font-medium text-sm text-sprimary mb-2 block">
                  Sweetness: <span className="text-smuted font-normal">{SWEETNESS_LABELS[mixer.sweetness]}</span>
                </label>
                <div className="flex gap-1.5">
                  {SWEETNESS_OPTIONS.map(opt => (
                    <button
                      key={opt.id}
                      onClick={() => updateMixer({ sweetness: opt.id })}
                      className={`flex-1 py-2 rounded-lg text-xs font-jakarta font-medium transition-all duration-200 ${
                        mixer.sweetness === opt.id
                          ? 'bg-ssecondary text-white shadow-subtle'
                          : 'bg-ssand/50 text-smuted hover:bg-ssand'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
