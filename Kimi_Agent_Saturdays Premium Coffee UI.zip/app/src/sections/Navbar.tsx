import { useState, useEffect } from 'react';
import { ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useCart } from '@/context/CartContext';
import { useStoreStatus } from '@/hooks/useStoreStatus';

const NAV_LINKS = [
  { label: 'Menu', target: '#menu' },
  { label: 'Signatures', target: '#signatures' },
  { label: 'Reviews', target: '#reviews' },
  { label: 'Location', target: '#location' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const { totalItems, justAdded, toggleCart } = useCart();
  const { isOpen, statusText } = useStoreStatus();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (target: string) => {
    const el = document.querySelector(target);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
        scrolled ? 'glass-nav py-3' : 'bg-transparent py-5'
      }`}
      style={{ top: scrolled ? 0 : '40px' }}
    >
      <div className="max-w-7xl mx-auto section-padding flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <motion.div
            className="w-10 h-10 bg-sprimary rounded-lg flex items-center justify-center cursor-pointer"
            whileHover={{ rotate: [0, -10, 10, -5, 0] }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-white font-outfit font-bold text-xl">S</span>
          </motion.div>
          <div className="hidden sm:block">
            <h1 className="font-outfit font-semibold text-lg leading-tight text-sprimary">
              Saturdays
            </h1>
            <p className="text-xs text-smuted font-jakarta -mt-0.5">Matcha & Coffee</p>
          </div>
        </div>

        {/* Nav Links - Desktop */}
        <div className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map(link => (
            <button
              key={link.target}
              onClick={() => scrollTo(link.target)}
              className="font-jakarta text-sm text-sprimary/80 hover:text-sprimary transition-colors duration-200 relative group"
            >
              {link.label}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-sprimary transition-all duration-300 group-hover:w-full" />
            </button>
          ))}
        </div>

        {/* Right Side */}
        <div className="flex items-center gap-4">
          {/* Store Status Badge */}
          <div
            className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-jakarta font-medium ${
              isOpen
                ? 'bg-green-50 text-green-700 border border-green-200'
                : 'bg-red-50 text-red-700 border border-red-200'
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                isOpen ? 'bg-green-500' : 'bg-red-500'
              }`}
            />
            {statusText}
          </div>

          {/* Cart Button */}
          <motion.button
            onClick={toggleCart}
            className="relative p-2.5 rounded-xl hover:bg-ssand/50 transition-colors duration-200"
            whileTap={{ scale: 0.95 }}
          >
            <ShoppingBag className="w-5 h-5 text-sprimary" />
            <AnimatePresence>
              {totalItems > 0 && (
                <motion.span
                  key={totalItems}
                  initial={justAdded ? { scale: 1.5 } : { scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                  className={`absolute -top-1 -right-1 w-5 h-5 bg-ssecondary text-white text-[10px] font-outfit font-bold rounded-full flex items-center justify-center ${
                    justAdded ? 'animate-bounce-badge' : ''
                  }`}
                >
                  {totalItems}
                </motion.span>
              )}
            </AnimatePresence>
          </motion.button>
        </div>
      </div>
    </nav>
  );
}
