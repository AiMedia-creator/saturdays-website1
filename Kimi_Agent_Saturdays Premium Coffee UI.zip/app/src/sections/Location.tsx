import { motion } from 'framer-motion';
import { MapPin, Navigation, MessageCircle, Clock, Phone } from 'lucide-react';
import { useStoreStatus } from '@/hooks/useStoreStatus';

export default function Location() {
  const { isOpen, nextChange } = useStoreStatus();

  return (
    <section id="location" className="py-20 section-padding bg-ssand/30">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 bg-saccent/60 text-sprimary text-xs font-jakarta font-medium rounded-full mb-4">
            Find Us
          </span>
          <h2 className="font-outfit text-4xl sm:text-5xl font-bold text-sprimary mb-4">
            Visit Saturdays
          </h2>
          <p className="font-jakarta text-smuted max-w-xl mx-auto">
            Come enjoy our handcrafted matcha and coffee in the heart of Nasr City
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 items-stretch">
          {/* Map Visual */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative h-80 lg:h-auto rounded-3xl overflow-hidden border border-ssand"
          >
            {/* Stylized Map Background */}
            <div className="absolute inset-0 bg-[#EDE9E0]">
              {/* Roads */}
              <div className="absolute top-0 left-1/3 w-8 h-full bg-white" />
              <div className="absolute top-1/2 left-0 w-full h-8 bg-white" />
              <div className="absolute top-1/4 left-0 w-full h-4 bg-white/60" />
              <div className="absolute top-0 left-2/3 w-4 h-full bg-white/60" />
              {/* Buildings */}
              <div className="absolute top-8 left-8 w-20 h-16 bg-[#D4CFC6] rounded" />
              <div className="absolute top-8 right-16 w-16 h-20 bg-[#D4CFC6] rounded" />
              <div className="absolute bottom-16 left-16 w-24 h-12 bg-[#D4CFC6] rounded" />
              <div className="absolute top-1/3 right-1/4 w-14 h-14 bg-[#C8C3BA] rounded" />
              {/* Park area */}
              <div className="absolute bottom-8 right-8 w-28 h-20 bg-[#C5D5B8] rounded-xl opacity-60" />
            </div>

            {/* Location Pin */}
            <div className="absolute top-1/2 left-1/3 -translate-x-1/2 -translate-y-1/2">
              <motion.div
                initial={{ y: -10 }}
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                className="relative"
              >
                <div className="w-12 h-12 bg-sprimary rounded-full flex items-center justify-center shadow-lg">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-0 h-0 border-l-8 border-r-8 border-t-8 border-transparent border-t-sprimary" />
              </motion.div>
              {/* Pulse ring */}
              <motion.div
                initial={{ scale: 1, opacity: 0.5 }}
                animate={{ scale: 2.5, opacity: 0 }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-sprimary rounded-full -z-10"
              />
            </div>

            {/* Map Label */}
            <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-sm rounded-xl p-3 flex items-center gap-3">
              <div className="w-10 h-10 bg-sprimary rounded-lg flex items-center justify-center shrink-0">
                <span className="text-white font-outfit font-bold text-lg">S</span>
              </div>
              <div>
                <p className="font-outfit font-semibold text-sm text-sprimary">Saturdays</p>
                <p className="font-jakarta text-[11px] text-smuted">
                  15 Al Mahrouki, Al Golf, Nasr City
                </p>
              </div>
            </div>
          </motion.div>

          {/* Info Card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-white rounded-3xl p-8 border border-ssand flex flex-col justify-between"
          >
            <div className="space-y-6">
              {/* Address */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-saccent/50 rounded-xl flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5 text-sprimary" />
                </div>
                <div>
                  <h4 className="font-outfit font-semibold text-sprimary mb-1">Address</h4>
                  <p className="font-jakarta text-sm text-smuted leading-relaxed">
                    15 Al Mahrouki, Al Golf,
                    <br />
                    Nasr City, Cairo Governorate
                  </p>
                </div>
              </div>

              {/* Hours */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-saccent/50 rounded-xl flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5 text-sprimary" />
                </div>
                <div>
                  <h4 className="font-outfit font-semibold text-sprimary mb-1">Opening Hours</h4>
                  <p className="font-jakarta text-sm text-smuted">
                    Daily: 8:00 AM — 9:00 PM
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <span
                      className={`w-2 h-2 rounded-full ${isOpen ? 'bg-green-500' : 'bg-red-500'}`}
                    />
                    <span className="font-jakarta text-xs text-smuted">{nextChange}</span>
                  </div>
                </div>
              </div>

              {/* Phone */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-saccent/50 rounded-xl flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5 text-sprimary" />
                </div>
                <div>
                  <h4 className="font-outfit font-semibold text-sprimary mb-1">Contact</h4>
                  <p className="font-jakarta text-sm text-smuted">0155 789 7297</p>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-3 mt-8 pt-6 border-t border-ssand">
              <a
                href="https://www.google.com/maps/search/Saturdays+Coffee+Matcha+Nasr+City"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-sprimary text-white font-jakarta text-sm font-medium hover:shadow-elevated transition-all duration-200"
              >
                <Navigation className="w-4 h-4" />
                Get Directions
              </a>
              <a
                href="https://wa.me/201557897297"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-[#25D366] text-white font-jakarta text-sm font-medium hover:shadow-elevated transition-all duration-200"
              >
                <MessageCircle className="w-4 h-4" />
                WhatsApp Us
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
