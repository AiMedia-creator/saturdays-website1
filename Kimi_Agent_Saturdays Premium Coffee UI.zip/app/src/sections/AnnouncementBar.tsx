import { useStoreStatus } from '@/hooks/useStoreStatus';

export default function AnnouncementBar() {
  const { isOpen, nextChange } = useStoreStatus();

  return (
    <div className="w-full bg-sprimary text-white py-2.5 px-4 relative z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-center gap-3 text-sm font-jakarta">
        <span className="relative flex h-2.5 w-2.5">
          <span
            className={`animate-pulse-dot absolute inline-flex h-full w-full rounded-full opacity-75 ${
              isOpen ? 'bg-green-400' : 'bg-red-400'
            }`}
          />
          <span
            className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
              isOpen ? 'bg-green-500' : 'bg-red-500'
            }`}
          />
        </span>
        <p className="text-center">
          <span className="font-medium">Saturdays Nasr City:</span>{' '}
          <span className={isOpen ? 'text-green-300' : 'text-red-300'}>
            {isOpen ? 'Open Now' : 'Closed'} — {nextChange}
          </span>
          <span className="text-white/60 mx-2">·</span>
          <span className="text-white/80">Order online, pickup in store!</span>
        </p>
      </div>
    </div>
  );
}
