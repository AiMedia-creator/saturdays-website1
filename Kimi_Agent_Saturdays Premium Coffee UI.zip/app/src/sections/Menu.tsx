import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Plus, Flame } from 'lucide-react';
import { menuItems } from '@/data/menuItems';
import type { Category } from '@/types';
import { CATEGORY_LABELS } from '@/types';
import DrinkCustomizer from './DrinkCustomizer';

const CATEGORIES: Category[] = ['all', 'matcha', 'coffee', 'blended', 'hot-drinks'];

export default function Menu() {
  const [activeCategory, setActiveCategory] = useState<Category>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);

  const filteredItems = useMemo(() => {
    return menuItems.filter(item => {
      const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
      const matchesSearch =
        searchQuery === '' ||
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, searchQuery]);

  const selectedItem = useMemo(
    () => menuItems.find(i => i.id === selectedItemId) || null,
    [selectedItemId]
  );

  return (
    <>
      <section id="menu" className="py-20 section-padding bg-ssand/30">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <span className="inline-block px-4 py-1.5 bg-saccent/60 text-sprimary text-xs font-jakarta font-medium rounded-full mb-4">
              Full Menu
            </span>
            <h2 className="font-outfit text-4xl sm:text-5xl font-bold text-sprimary mb-4">
              Explore Our Drinks
            </h2>
            <p className="font-jakarta text-smuted max-w-xl mx-auto">
              From premium matcha creations to artisanal coffee blends
            </p>
          </motion.div>

          {/* Search Bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="max-w-md mx-auto mb-8"
          >
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-smuted" />
              <input
                type="text"
                placeholder="Search drinks..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-11 pr-4 py-3 rounded-xl bg-white border border-ssand font-jakarta text-sm text-sprimary placeholder:text-smuted/60 focus:outline-none focus:ring-2 focus:ring-sprimary/20 focus:border-sprimary/30 transition-all"
              />
            </div>
          </motion.div>

          {/* Category Tabs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-wrap justify-center gap-2 mb-10"
          >
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2.5 rounded-xl font-jakarta text-sm font-medium transition-all duration-200 ${
                  activeCategory === cat
                    ? 'bg-sprimary text-white shadow-subtle'
                    : 'bg-white text-smuted hover:bg-white/80 border border-ssand'
                }`}
              >
                {CATEGORY_LABELS[cat]}
              </button>
            ))}
          </motion.div>

          {/* Menu Grid */}
          <motion.div layout className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            <AnimatePresence mode="popLayout">
              {filteredItems.map((item, index) => (
                <motion.div
                  key={item.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3, delay: index * 0.03 }}
                  className="group bg-white rounded-2xl border border-ssand overflow-hidden hover:shadow-elevated hover:-translate-y-0.5 transition-all duration-300"
                >
                  {/* Card Header with Gradient */}
                  <div className={`${item.imageGradient} h-32 relative p-4`}>
                    {item.tag && (
                      <span className="inline-block px-2.5 py-1 bg-white/90 backdrop-blur-sm rounded-lg text-[10px] font-jakarta font-semibold text-sprimary uppercase tracking-wide">
                        {item.tag}
                      </span>
                    )}
                    {item.isPopular && (
                      <span className="absolute top-4 right-4 flex items-center gap-1 px-2 py-1 bg-ssecondary/90 backdrop-blur-sm rounded-lg text-[10px] font-jakarta font-semibold text-white">
                        <Flame className="w-3 h-3" />
                        Popular
                      </span>
                    )}
                    {/* Mini cup visual */}
                    <div className="absolute bottom-3 right-4">
                      <div className="w-12 h-16 rounded-b-xl border-2 border-white/40 bg-white/15 backdrop-blur-sm relative overflow-hidden">
                        <div
                          className="absolute bottom-0 left-0 right-0 h-3/4 opacity-60"
                          style={{
                            background:
                              item.category === 'matcha'
                                ? 'linear-gradient(to top, #7ba86a, #E5ECC8)'
                                : item.category === 'coffee'
                                ? 'linear-gradient(to top, #a89078, #d4c8b8)'
                                : item.category === 'blended'
                                ? 'linear-gradient(to top, #c8b8a0, #e8ddd0)'
                                : 'linear-gradient(to top, #8a7a68, #c4b8a8)',
                          }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-4">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <h3 className="font-outfit font-semibold text-base text-sprimary leading-tight">
                        {item.name}
                      </h3>
                      <span className="font-outfit font-bold text-ssecondary shrink-0">
                        {item.price} EGP
                      </span>
                    </div>
                    <p className="font-jakarta text-xs text-smuted leading-relaxed mb-3 line-clamp-2">
                      {item.description}
                    </p>
                    <button
                      onClick={() => setSelectedItemId(item.id)}
                      className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-sprimary/5 hover:bg-sprimary text-sprimary hover:text-white font-jakarta text-sm font-medium transition-all duration-200 group/btn"
                    >
                      <Plus className="w-4 h-4 transition-transform group-hover/btn:rotate-90" />
                      Customize & Add
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>

          {filteredItems.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16"
            >
              <p className="font-jakarta text-smuted text-lg">
                No drinks found matching your search.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveCategory('all');
                }}
                className="mt-4 text-ssecondary font-jakarta font-medium hover:underline"
              >
                Clear filters
              </button>
            </motion.div>
          )}
        </div>
      </section>

      {/* Customization Modal */}
      <DrinkCustomizer
        item={selectedItem}
        isOpen={!!selectedItemId}
        onClose={() => setSelectedItemId(null)}
      />
    </>
  );
}
