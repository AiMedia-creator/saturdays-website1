import React, { createContext, useContext, useState, useCallback, useRef } from 'react';
import type { CartItem, CartItemCustomization, MenuItem } from '@/types';
import { MILK_PRICES } from '@/types';

interface CartContextType {
  items: CartItem[];
  isCartOpen: boolean;
  justAdded: boolean;
  totalItems: number;
  totalPrice: number;
  addItem: (item: MenuItem, customization: CartItemCustomization) => void;
  removeItem: (cartId: string) => void;
  updateQuantity: (cartId: string, delta: number) => void;
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;
  clearCart: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [justAdded, setJustAdded] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = items.reduce((sum, item) => sum + item.finalPrice * item.quantity, 0);

  const addItem = useCallback((item: MenuItem, customization: CartItemCustomization) => {
    const milkPrice = MILK_PRICES[customization.milk];
    const finalPrice = item.price + milkPrice;
    const cartId = `${item.id}-${customization.sweetness}-${customization.milk}-${Date.now()}`;

    setItems(prev => [...prev, { cartId, item, quantity: 1, customization, finalPrice }]);
    setJustAdded(true);

    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => setJustAdded(false), 600);
  }, []);

  const removeItem = useCallback((cartId: string) => {
    setItems(prev => prev.filter(i => i.cartId !== cartId));
  }, []);

  const updateQuantity = useCallback((cartId: string, delta: number) => {
    setItems(prev =>
      prev.map(i => {
        if (i.cartId === cartId) {
          const newQty = Math.max(1, i.quantity + delta);
          return { ...i, quantity: newQty };
        }
        return i;
      })
    );
  }, []);

  const openCart = useCallback(() => setIsCartOpen(true), []);
  const closeCart = useCallback(() => setIsCartOpen(false), []);
  const toggleCart = useCallback(() => setIsCartOpen(prev => !prev), []);
  const clearCart = useCallback(() => setItems([]), []);

  return (
    <CartContext.Provider
      value={{
        items,
        isCartOpen,
        justAdded,
        totalItems,
        totalPrice,
        addItem,
        removeItem,
        updateQuantity,
        openCart,
        closeCart,
        toggleCart,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within a CartProvider');
  return context;
}
